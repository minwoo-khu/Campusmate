CampusMate Windows Portable

1) Unzip this file.
2) Run CampusMate.exe.
3) Keep all files in the same folder.
