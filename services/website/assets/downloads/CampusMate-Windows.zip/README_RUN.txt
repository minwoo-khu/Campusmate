﻿CampusMate (Windows)

1) Unzip this archive.
2) Run CampusMate.exe.
